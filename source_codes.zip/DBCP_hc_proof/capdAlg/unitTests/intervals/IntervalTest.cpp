/*
 * IntervalTest.cpp
 *
 *  Created on: 2009-09-02
 *      Author: iikapela
 */

#include "../gtestHeader.h"

 main(int argc, char** argv) {
  ::testing::InitGoogleTest(&argc, argv);
  int result = RUN_ALL_TESTS();
  return result;
}
