/* include/capd/config-capdAlg.h.  Generated from config-capdAlg.h.in by configure.  */
/* include/capd/config-capdAlg.h.in.  Generated from configure.ac by autoheader.  */

/* Define to 1 if you have the `gmp' library (-lgmp). */
/* #undef HAVE_LIBGMP */

/* Define to 1 if you have the `gmpxx' library (-lgmpxx). */
/* #undef HAVE_LIBGMPXX */

/* Define to 1 if you have the `mpfr' library (-lmpfr). */
/* #undef HAVE_LIBMPFR */

/* Define to 1 if your C compiler doesn't accept -c and -o together. */
/* #undef NO_MINUS_C_MINUS_O */

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "BUG-REPORT-ADDRESS"

/* Define to the full name of this package. */
#define PACKAGE_NAME "capdAlg"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "capdAlg 1.0"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "capdalg"

/* Define to the version of this package. */
#define PACKAGE_VERSION "1.0"
