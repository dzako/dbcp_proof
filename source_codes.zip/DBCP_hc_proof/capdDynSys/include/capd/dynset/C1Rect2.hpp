/////////////////////////////////////////////////////////////////////////////
/// @file C1Rect2.hpp
/// @deprecated
/// @author kapela
/// Created on: Oct 25, 2009
/////////////////////////////////////////////////////////////////////////////

// Copyright (C) 2009 by the CAPD Group.
//
// This file constitutes a part of the CAPD library,
// distributed under the terms of the GNU General Public License.
// Consult  http://capd.ii.uj.edu.pl/ for details.

#ifndef _CAPD_DYNSYS_C1RECT2_HPP_
#define _CAPD_DYNSYS_C1RECT2_HPP_

#include "capd/dynset/C1Rect2.h"

#endif // _CAPD_C1RECT2_HPP_

